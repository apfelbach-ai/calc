# In einer Colab-Zelle (backend_logic.py)
import random
import json

# Wichtiger Hinweis für Lambda: Variablen außerhalb von Funktionen
# bleiben zwischen Aufrufen erhalten, ABER sind NICHT dauerhaft!
# Wenn Lambda "warm" bleibt, ist es da, sonst wird es gelöscht.
# Für dauerhafte Speicherung bräuchte man eine Datenbank wie DynamoDB.
temp_problem_store = {} # Speichert Aufgaben temporär

def generate_math_problem():
    num1 = random.randint(2, 10)
    num2 = random.randint(2, 10)
    operators = ['+', '-', '*']
    operator = random.choice(operators)

    problem_string = f"{num1} {operator} {num2}"

    if operator == '+':
        correct_answer = num1 + num2
    elif operator == '-':
        correct_answer = num1 - num2
    else: # '*'
        correct_answer = num1 * num2

    problem_id = str(random.randint(100000, 999999)) # Eine einfache ID
    temp_problem_store[problem_id] = correct_answer # Antwort temporär speichern

    return {"problem": problem_string, "problem_id": problem_id}

def check_math_answer(problem_id, user_answer):
    correct_answer = temp_problem_store.get(problem_id)

    if correct_answer is None:
        # Das Problem wurde nicht gefunden (z.B. weil Lambda neu gestartet wurde)
        return {"is_correct": False, "message": "Problem nicht gefunden oder abgelaufen."}

    is_correct = (user_answer == correct_answer)

    # Optional: Lösche das Problem, nachdem es geprüft wurde
    # if problem_id in temp_problem_store:
    #    del temp_problem_store[problem_id]

    return {"is_correct": is_correct, "correct_answer": correct_answer}


# --- Ab hier ist Code, der nur für Lambda ist, nicht für Colab-Tests ---
def lambda_handler(event, context):
    """
    Dies ist die Hauptfunktion, die AWS Lambda aufruft.
    Das 'event' enthält die Infos von API Gateway (z.B. den Pfad und Daten).
    """
    # Den Pfad aus dem Event holen und sicherstellen, dass er mit einem '/' beginnt
    # und Stage-Namen entfernt, falls vorhanden
    path = event.get('path', '/')
    if path.startswith('/prod/'): # Wenn deine Stage 'prod' heißt, anpassen!
        path = path[len('/prod'):] # Entferne '/prod' vom Pfad
    # Wenn du eine andere Stage hast (z.B. '/dev/'), passe diese Zeile entsprechend an.
    # Oder du kannst eine allgemeinere Lösung wählen:
    # path = '/' + '/'.join(path.split('/')[2:]) if len(path.split('/')) > 2 else path
    # Die obige einfache Lösung ist für den Anfang besser.


    http_method = event.get('httpMethod')

    # Wichtig für CORS (Cross-Origin Resource Sharing): Erlaubt deinem Frontend,
    # das auf S3 liegt, mit diesem Backend zu sprechen.
    headers = {
        "Access-Control-Allow-Origin": "*",  # Erlaubt Zugriffe von jeder Domain
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
    }

    # API Gateway sendet zuerst eine OPTIONS-Anfrage (Preflight), die wir beantworten müssen.
    if http_method == 'OPTIONS':
        return {'statusCode': 200, 'headers': headers}

    # Wenn der Browser nach einer neuen Aufgabe fragt (GET /problem)
    if path == '/problem' and http_method == 'GET':
        problem_data = generate_math_problem()
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(problem_data)
        }

    # Wenn der Browser die Antwort sendet (POST /check)
    elif path == '/check' and http_method == 'POST':
        try:
            # Der Body der Anfrage enthält die Daten vom Frontend (JSON)
            body = json.loads(event.get('body', '{}'))
            problem_id = body.get('problem_id')
            user_answer = body.get('answer')

            if problem_id is None or user_answer is None:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({"error": "Fehlende ID oder Antwort."})
                }

            result = check_math_answer(problem_id, user_answer)

            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps(result)
            }
        except json.JSONDecodeError:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({"error": "Ungültiges JSON-Format."})
            }
        except Exception as e:
            # Für alle anderen Fehler
            return {
                'statusCode': 500,
                'headers': headers,
                'body': json.dumps({"error": f"Interner Serverfehler: {str(e)}"})
            }

    # Falls der Pfad oder die Methode nicht bekannt ist
    return {
        'statusCode': 404,
        'headers': headers,
        'body': json.dumps({"message": "Ressource nicht gefunden."})
    }